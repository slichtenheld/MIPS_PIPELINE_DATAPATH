
//need function to store instructions bitwise
//need function to combine bits into 32 bit data
//need function to convert to hex

//need separate functions for R/I/J type 
//R = [opcode|rs|rt|rd|shift|funct]
//I = [opcode|rs|rt|immediate]
//J = [opcode|address]


#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include "instr.h"
#include "fileIO.h"
#include "decoder.h"
#include "conv.h"
using namespace std;


//vector<string> readfile (char*); 
//string parser (string, int); 
//void newfile (char*);
//string int2bit(int);
string retHex(unsigned int);
string retHexAddr(unsigned int);

int main(int argc, char *argv[]){

	decoder a;

	//make sure both input and output filenames are given
	if (argc != 3) {
		cout << "Enter file input followed by output. " << endl << "Exiting..." << endl;
		return 0;
	}
	//make newfile template
	newfile(argv[2]);
	//read in file with each line in a new spot in vector
	vector<string> mif = readfile (argv[1]);

	unsigned int i = 0;

	for ( ; i < mif.size(); i++) {
		string text = "    " + retHexAddr(i) + "  :   " + retHex(a.decode(mif.at(i))) + ";\n";
		appendfile (text, argv[2]);
//		cout  << "    " << retHexAddr(i) << "  :   "; 
//		cout << retHex(a.decode(mif.at(i))) << ";" << endl;
		//i gives you address, so append should be called per line
	}
		appendfile ("    [" + retHexAddr(i) + "..0ff]  :   00000000;\nEND;", argv[2]);
//		cout << "    [" << retHexAddr(i) << "..0ff]  :   00000000;" << endl; 

	return 0;
}

string retHex(unsigned int address){
	string hex[]={"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
	vector<int> rev;
	string ret="";
	for (int i = 0; i < 8; i++){
		rev.push_back(address%16);
		address = address/16;
	}
	for (int i=7;i>=0;i--){
		ret.append(hex[rev.at(i)]);
	}
	return ret;
}

string retHexAddr(unsigned int address){
	string hex[]={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"};
	vector<int> rev;
	string ret="";
	for (int i = 0; i < 3; i++){
		rev.push_back(address%16);
		address = address/16;
	}
	for (int i=2;i>=0;i--){
		ret.append(hex[rev.at(i)]);
	}
	return ret;
}






