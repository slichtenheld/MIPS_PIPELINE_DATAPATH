#ifndef FILEIO_H
#define FILEIO_H

#include <cstring>
#include <string>
#include <vector>
using namespace std;
#include "conv.h"


vector<string> readfile (char*);
void newfile(char*);
void appendfile(string, string);



vector<string> readfile (char* inputTxt){
    string line;
    vector<string> str; //returning string post-edits
    vector<string> labels; //temporary recording of labels
    vector<int> labelsVal; 
    ifstream inFile (inputTxt); 
    //check to see if able to open file
    if (inFile.is_open()) {
        //put each line in different line of vector of string
        int i = 0, num = 0; //record addresses of labels and amount of labels
        while (getline(inFile,line)) {  
            //don't add labels with colons
            if (line.find(":") == string::npos) {
                str.push_back(line);
                i++;
            }
            else {
                labels.push_back(line.substr(0,line.find(":")));
                labelsVal.push_back(i);
                num++;
            }
        }
        inFile.close();
        //This loop swaps labels with appropriate hex values
        for (int l=0;l<i;l++){
            for (int k=0;k<num;k++){
                if(str.at(l).find(labels.at(k)) != string::npos){
                    str.at(l).replace(str.at(l).find(labels.at(k)),labels.at(k).length(), int2hex(labelsVal.at(k))); 
                }
            }
        }
    }
    else cout << "File not found." << endl;
    return str;
}
    
void newfile(char* filename){
    ofstream newfile (filename);
    if (newfile.is_open()) {
            newfile << "\nWIDTH=32;\nDEPTH=256;\n\nADDRESS_RADIX=HEX;\nDATA_RADIX=HEX;\n\nCONTENT BEGIN\n";
            newfile.close();
        }
    else std::cout << "Unable to open file WRITE" << std::endl;
}


//void appendfile()
void appendfile(string entry, string name) { 
    ofstream file (name.c_str(), ofstream::app);
    if (file.is_open()) {
        file << entry;
        file.close();
    }
    else cout << "Unable to open file APPEND" << endl;      
} 

#endif