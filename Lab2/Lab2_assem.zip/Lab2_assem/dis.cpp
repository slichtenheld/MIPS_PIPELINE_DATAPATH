#include <iostream>
using namespace std;

#include "fileIO.h"


int main(int argc, char *argv[]){

	if (argc != 3) {
		cout << "Enter file input followed by output. " << endl << "Exiting..." << endl;
		return 0;
	}

	vector<string> txt = readfile (argv[1]);

	for (unsigned int = 0; i < txt.size(); i++){
		cout << txt.at(i) << endl;

	}

}