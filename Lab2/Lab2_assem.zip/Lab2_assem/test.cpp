#include <iostream>
#include <string>
#include <math.h>
using namespace std;

int reg2dec(string line);

int main(){

	string line = " $16, $17, $18";

	cout << reg2dec(line) << endl;

}

int reg2dec(string line){
	char hex[16]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

	unsigned int start = line.find("$");
	unsigned int end = line.find(",");
//	if (end == string::npos) end = line.length();
	string regNum = line.substr(start+1,(end-start-1)); //grabs reg string
//	cout << "*" << regNum << "*" << endl;
	int regVal = 0;
	for (unsigned int i = 0; i < regNum.length(); i++) {
	  	for (int k = 0; k < 10; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(10,regNum.length()-i-1);
	  			//cout << " #" << regVal << " ";
		  		break;
		  	}
	  	}
	}
	line.erase(0,end+1);
	return regVal;
}