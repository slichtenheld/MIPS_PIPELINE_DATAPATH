#ifndef DECODE_H
#define DECODE_H

//need separate functions for R/I/J type 
//R = [opcode|rs|rt|rd|shift|funct]
//I = [opcode|rs|rt|immediate]
//J = [opcode|address]

//R_op $rd, $rs, $rt
//I_op $rt, $rs, immed //ex// lui $s1, 20 //ex2// sc $s1,20($20)
//J_op immed
struct typecode {
    int type;
    int code;
};

void decode(vector<string>);


void decode(vector<string> instr){
	const string rType[] = {"add","addu","and","jr","nor","or","slt","sltu","sll","srl","sub","subu"};
	const int 	 rOp[]	 = {add, addu, AND, jr, nor, OR, slt, sltu, sll, srl, sub, subu};
	const int 	 rFunct[]= {add_f, addu_f, and_f, jr_f, nor_f, or_f, slt_f, sltu_f, sll_f, srl_f, sub_f, subu_f};
	const string iType[] = {"addi","addiu","andi","beq","bne","lbu","lhu","lui","lw","ori","slti", "sltiu","sb","sh","sw"};
	const int 	 iOp[]   = {addi, addiu, andi, beq, bne, lbu, lhu, lui, lw, ori, slti, sltiu, sb, sh, sw};
	const string jType[] = {"j","jal"};
	const int 	 jOp[]   = {j, jal};

	for (unsigned int = 0; i < instr.size(); i++){
		string line = instr.at(i);
		int strlength = line.find(" ");
		string opcode = line.substr(0,strlength);
		
	}
}

//find opcode string
//compare with list of opcodes
//convert hex value of opcode to binary string

//if R type

int op2int(string opcode, ){
//check if R_TYPE
const string rType[] = {"add","addu","and","jr","nor","or","slt","sltu","sll","srl","sub","subu"};
const int 	 rOp[]	 = {add, addu, AND, jr, nor, OR, slt, sltu, sll, srl, sub, subu};

	for (int i = 0; i < 12; i++){
		if (opcode==rType[i]) return rOp[i];
	}
//Check if I_TYPE
const string iType[] = {"addi","addiu","andi","beq","bne","lbu","lhu","lui","lw","ori","slti", "sltiu","sb","sh","sw"};
const int 	 iOp[]   = {addi, addiu, andi, beq, bne, lbu, lhu, lui, lw, ori, slti, sltiu, sb, sh, sw};

	for (int i = 0; i < 15; i++){
		if (opcode==iType[i]) return iOp[i];
	}

//CHECK IF J_TYPE
const string jType[] = {"j","jal"};
const int 	 jOp[]   = {j, jal};
	for (int i = 0; i < 2; i++){
		if (opcode==jType[i]) return jOp[i];
	}
	return 0;
}



string parser(string line, int address){
	if (line.find(":") != string::npos) cout << "----" << address << endl;
	int length = line.find(" ");
	return line.substr(0,length);
}

#endif