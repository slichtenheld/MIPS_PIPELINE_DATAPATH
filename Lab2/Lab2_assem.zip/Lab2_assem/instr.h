#ifndef INSTR_H
#define INSTR_H

#define add 	0x00
#define addi 	0x08
#define addiu	0x09
#define addu 	0x00
#define AND 	0x00
#define andi 	0x0C
#define beq		0x04
#define bne		0x05
#define j 		0x02
#define jal		0x03
#define jr		0x00
#define lbu		0x24
#define lhu		0x25
#define lui		0x0F
#define lw		0x23
#define nor		0x00
#define OR 		0x00 
#define ori 	0x0D 
#define slt 	0x00 
#define slti 	0x0A
#define sltiu 	0x0B
#define sltu 	0x00 
#define sll 	0x00 
#define srl 	0x00 
#define sb 		0x28
#define sh 		0x29
#define sw 		0x2B
#define sub 	0x00 	
#define subu 	0x00

#define r_type	0x3 
#define i_type	0x2
#define j_type	0x1

#define add_t 	r_type
#define addi_t 	i_type
#define addiu_t	i_type
#define addu_t 	r_type
#define and_t 	r_type
#define andi_t 	i_type
#define beq_t	i_type
#define bne_t	i_type
#define j_t 	j_type
#define jal_t	j_type
#define jr_t	r_type
#define lbu_t	i_type
#define lhu_t	i_type
#define lui_t	i_type
#define lw_t	i_type
#define nor_t	r_type
#define or_t	r_type
#define ori_t 	i_type
#define slt_t 	r_type
#define slti_t 	i_type
#define sltiu_t i_type
#define sltu_t 	r_type
#define sll_t 	r_type
#define srl_t	r_type
#define sb_t 	i_type
#define sh_t 	i_type
#define sw_t 	i_type
#define sub_t 	r_type 	
#define subu_t 	r_type

#define add_f	0x20
#define addu_f	0x21
#define and_f 	0x24
#define jr_f 	0x08
#define nor_f	0x27
#define or_f 	0x25
#define slt_f	0x2A
#define sltu_f 	0x2B
#define sll_f 	0x00 
#define srl_f 	0x02
#define sub_f	0x22
#define subu_f	0x23

#define ALU_add	0x0
#define ALU_sub	0x1
#define ALU_nor	0x2 
#define ALU_or 	0x3 
#define ALU_slt	0x4 
#define ALU_sll 0x5 
#define ALU_srl 0x6

#endif