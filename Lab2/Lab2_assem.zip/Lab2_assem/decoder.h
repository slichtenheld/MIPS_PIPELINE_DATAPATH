#ifndef DECODER_H
#define DECODER_H

//need separate functions for R/I/J type 
//R = [opcode|rs|rt|rd|shift|funct]
//I = [opcode|rs|rt|immediate]
//J = [opcode|address]

//R_op $rd, $rs, $rt
//I_op $rt, $rs, immed //ex// lui $s1, 20 //ex2// sc $s1,20($20)
//J_op immed


//#include "conv.h"
#include "instr.h"
#include <vector>
#include <string>
#include <iostream>
#include <math.h>
using namespace std;

class decoder {
private:
	string rType[12] = {"add","addu","and","jr","nor","or","slt","sltu","sll","srl","sub","subu"};
	int rOp[12] = {add, addu, AND, jr, nor, OR, slt, sltu, sll, srl, sub, subu};
	int rFunct[12] = {add_f, addu_f, and_f, jr_f, nor_f, or_f, slt_f, sltu_f, sll_f, srl_f, sub_f, subu_f};
	string iType[15] = {"addi","addiu","andi","beq","bne","lbu","lhu","lui","lw","ori","slti", "sltiu","sb","sh","sw"};
	int iOp[15] = {addi, addiu, andi, beq, bne, lbu, lhu, lui, lw, ori, slti, sltiu, sb, sh, sw};
	string jType[2] = {"j","jal"};
	int jOp[2] = {j, jal};

	char hex[16]={'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};

	//helpers
	void getOp(); //pulls instru from line, update instr_type
	void decodeR();
	void decodeI();
	void decodeJ();
	//subhelpers
	int reg2dec();
	int hex2dec();
	int dec2dec();
	int offset_dec();
	int offset_hex();
	int offset_reg(); 

	string line;
	int instr;
	int instr_type;
	int opcode31_26;
	int funct5_0;
public:
	decoder();
	int decode(string instruction);
};

decoder::decoder(){}

int decoder::decode(string instruction) {
	line = instruction;
	getOp();
	if (instr_type == r_type) decodeR();
	else if (instr_type == i_type) decodeI();
	else if (instr_type == j_type) decodeJ();
	return instr;
}

void decoder::getOp(){ //sets opType and sets 6 most significant bits(opcode)
	int length = line.find(" ");
	string opcode = line.substr(0, length); //grabs opcode
	line.erase(0,length+1); //get rid of opcode to make next parsing easier

	for (int i = 0; i < 12; i++){
		if (opcode==rType[i]) {
			opcode31_26 = 0; //all r_type have opcode=zero
			funct5_0 = rFunct[i];
			instr_type = r_type;
			return;
		}
	}
	for (int i = 0; i < 15; i++){
		if (opcode==iType[i]){
			opcode31_26 = iOp[i];
			instr_type = i_type;
			return;
		} 
	}
	for (int i = 0; i < 2; i++){
		if (opcode==jType[i]) {
			opcode31_26 = jOp[i];
			instr_type = j_type;
			return;
		}
	}
}

void decoder::decodeR() { //R = [opcode|rs|rt|rd|shift|funct]
	// cout << "RTYPE" << endl;
	int rs = 0, rd = 0, rt = 0, shamt = 0;
	
	if (funct5_0==add_f || funct5_0==addu_f || funct5_0==and_f || funct5_0==nor_f || funct5_0==or_f || funct5_0==slt_f || funct5_0 == sltu_f || funct5_0==sub_f || funct5_0==subu_f){
		rd = reg2dec();
		rs = reg2dec();
		rt = reg2dec();
	}
	else if (funct5_0==sll_f || funct5_0==srl_f){
		rd = reg2dec();
		rt = reg2dec();
		shamt = dec2dec();
	}
	else if (funct5_0==jr_f){
		rs = reg2dec();
	}
	else cout << "ERRORRRRRRRRRRRRRRRRRRRRR" << endl;


	// rd = reg2dec();
	
	// if (funct5_0 != jr_f){
	// 	rs = reg2dec();
	// 	if (line.find("$") != string::npos) rt = reg2dec();
	// 	else shamt=dec2dec();
	// }
	// cout << "rd = " << rd << endl;
	// cout << "rs = " << rs << endl;
	// cout << "rt = " << rt << endl;
	//cout << "shamt = " << shamt << endl;
	instr = (opcode31_26<<26) + (rs << 21) + (rt << 16) + (rd << 11) + (shamt << 6) + funct5_0;
	// cout << "int = " << instr << endl; 
}

void decoder::decodeI(){ //I_op $rt, $rs, immed //ex// lui $s1, 20 //ex2// sc $s1,20($20)
	// cout << "ITYPE" << endl;
	int rt = 0, rs= 0, immed = 0;
	//rt = reg2dec();
	//cout << "rs = " << rt << endl;
	if (opcode31_26==addi || opcode31_26==addiu || opcode31_26==andi || opcode31_26==ori || opcode31_26==slti || opcode31_26==sltiu) {
		rt = reg2dec();
		rs = reg2dec();
		immed = hex2dec();
		
	}
	else if (opcode31_26==beq || opcode31_26==bne){
		rs = reg2dec();
		rt = reg2dec();
		immed = hex2dec();
	}
	else if (opcode31_26==lw || opcode31_26==lbu || opcode31_26==lhu || opcode31_26==sb || opcode31_26==sh || opcode31_26==sw){
		rt = reg2dec();
		if (line.find("x")!= string::npos) immed = offset_hex();
		else immed = offset_dec();
		rs = offset_reg();
	} 
	else if (opcode31_26==lui){
		rt = reg2dec();
		immed = hex2dec();
	}
	else cout << "ERRORRRRRRRRRRRRRRRRRRRRR" << endl;

//	cout << "rs = " << rt << endl;
//	cout << "rt = " << rs << endl;
//	cout << "immed = " << immed << endl;
	instr = (opcode31_26<<26) + (rs << 21) + (rt << 16) + (immed & 0xFFFF);
//	cout << "int = " << unsigned(instr) << endl; 
	//cout << "NOT HERE" << endl;
}

void decoder::decodeJ(){
	// cout << "JTYPE" << endl;
	int immed = 0;
	immed = hex2dec();
	//cout << "immed = " << immed << endl;
	instr = (opcode31_26<<26) + immed;
	//cout << "int = " << instr << endl; cout << "int = " << instr << endl; 
}

int decoder::reg2dec(){
	unsigned int start = line.find("$");
	unsigned int end = line.find(",");
	string regNum = line.substr(start+1,(end-start-1)); //grabs reg string
	int regVal = 0;
	for (unsigned int i = 0; i < regNum.length(); i++) {
	  	for (int k = 0; k < 10; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(10,regNum.length()-i-1);
		  		break;
		  	}
	  	}
	}
	line.erase(0,end+1);
	return regVal;
}

int decoder::hex2dec(){
	unsigned int start = line.find("x");
	unsigned int end = line.length();
	string regNum = line.substr(start+1,(end-start-1)); //grabs reg string
	int regVal = 0;
//	cout << "SHAMT: " << regNum << endl; 
	for (unsigned int i = 0; i < regNum.length(); i++) {
	  	for (int k = 0; k < 16; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(16,regNum.length()-i-1);
		  		break;
		  	}
	  	}
	}
	line.erase(0,end+1);
	return regVal;
}

int decoder::dec2dec(){
	unsigned int end = line.length();
	string regNum = line.substr(1,end-1); //grabs shamt string
	int regVal = 0; 
//	cout << "SHAMT:" << regNum << endl; 
	for (unsigned int i = 0; i < regNum.length(); i++) {
	  	for (int k = 0; k < 10; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(10,regNum.length()-i-1);
		  		break;
		  	}
	  	}
	}
	return regVal;
}

int decoder::offset_dec(){
//	cout << "offset_dec string = " << line << endl;
	unsigned int end = line.find("(");
	string regNum = line.substr(1,end-1); //grabs dec string
	int regVal = 0; 
	int negative = 1;
//	cout << "SHAMT:" << regNum << endl; 
	unsigned int i = 0;
//	unsigned int length = regNum.length;
	if (regNum.at(0)=='-') {
		negative = -1;
//		i=1;
//		length--;
	}
	for ( ; i < regNum.length(); i++) {
	  	for (int k = 0; k < 10; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(10,regNum.length()-i-1);
		  		break;
		  	}
	  	}
	}
	return negative*regVal;
}

int decoder::offset_hex(){
//	cout << "offset_hex string = " << line << endl;
	unsigned int start = line.find("x");
	unsigned int end = line.find("(");
	string regNum = line.substr(start+1,(end-start-1)); //grabs hex string
	int regVal = 0;
//	cout << "SHAMT: " << regNum << endl; 
	for (unsigned int i = 0; i < regNum.length(); i++) {
	  	for (int k = 0; k < 16; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(16,regNum.length()-i-1);
		  		break;
		  	}
	  	}
	}
	return regVal;
}

int decoder::offset_reg(){
//	cout << "offset_reg string = " << line << endl;
	unsigned int start = line.find("$");
	unsigned int end = line.find(")");
	string regNum = line.substr(start+1,(end-start-1)); //grabs reg string
	int regVal = 0;
	for (unsigned int i = 0; i < regNum.length(); i++) {
	  	for (int k = 0; k < 10; k++) {
	  		if (regNum.at(i)==hex[k]) {
	  			regVal += k*pow(10,regNum.length()-i-1);
		  		break;
		  	}
	  	}
	}
	return regVal;
} 

#endif