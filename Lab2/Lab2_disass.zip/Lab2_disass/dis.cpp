#include <iostream>
using namespace std;

#include "fileIO.h"
#include "encoder.h"

int main(int argc, char *argv[]){

	if (argc != 3) {
		cout << "Enter file input followed by output. " << endl << "Exiting..." << endl;
		return 0;
	}

	vector<string> txt = readfile(argv[1]);
	newfile(argv[2]);
	encoder a;

	for (unsigned int i = 0; i < txt.size(); i++){
		cout << txt.at(i);
		appendfile(a.encode(txt.at(i)), argv[2]);
	}

}