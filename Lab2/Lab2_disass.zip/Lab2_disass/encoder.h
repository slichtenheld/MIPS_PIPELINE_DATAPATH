#ifndef ENCODER_H
#define ENCODER_H

//need separate functions for R/I/J type 
//R = [opcode|rs|rt|rd|shift|funct]
//I = [opcode|rs|rt|immediate]
//J = [opcode|address]

//R_op $rd, $rs, $rt
//I_op $rt, $rs, immed //ex// lui $s1, 20 //ex2// sc $s1,20($20)
//J_op immed


//#include "conv.h"
#include "instr.h"
#include <vector>
#include <string>
#include <iostream>
#include <math.h>
using namespace std;

class encoder {
private:
	string rType[12] = {"add","addu","and","jr","nor","or","slt","sltu","sll","srl","sub","subu"};
	int rOp[12] = {add, addu, AND, jr, nor, OR, slt, sltu, sll, srl, sub, subu};
	int rFunct[12] = {add_f, addu_f, and_f, jr_f, nor_f, or_f, slt_f, sltu_f, sll_f, srl_f, sub_f, subu_f};
	string iType[15] = {"addi","addiu","andi","beq","bne","lbu","lhu","lui","lw","ori","slti", "sltiu","sb","sh","sw"};
	int iOp[15] = {addi, addiu, andi, beq, bne, lbu, lhu, lui, lw, ori, slti, sltiu, sb, sh, sw};
	string jType[2] = {"j","jal"};
	int jOp[2] = {j, jal};

	char hex[16]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	//helpers
	void getOp(); //pulls instru from line, update instr_type
	void encodeR();
	void encodeI();
	void encodeJ();
	//subhelpers
	void hex2dec();
	string int2string(int passed);
	string int2hex(unsigned int passed);

	string line;
	unsigned int instr;
	unsigned int opcode;
	string mips;
public:
	encoder();
	string encode(string instruction);
};

encoder::encoder(){

} 

string encoder::encode(string instruction) {
	line = instruction;
	hex2dec(); //store converted decimal value into variable(string) line
	getOp();
	return mips;
}

void encoder::getOp(){ //sets opType and sets 6 most significant bits(opcode)
	opcode=instr>>26;

 	if (opcode==0) { //all r_type have opcode=zero
 		encodeR();
 		cout << "  " << mips;
		return;
	}
	
	for (int i = 0; i < 15; i++){
		if (opcode==iOp[i]){
			mips = iType[i];
			encodeI();
			cout << "  " << mips;
	 		return;
		} 
	
	}
	for (int i = 0; i < 2; i++){
		if (opcode==jOp[i]) {
			mips = jType[i];
			encodeJ();
			cout << "  " << mips;
	 		return;
		}
	}	

}

void encoder::encodeR() { //R = [opcode|rs|rt|rd|shift|funct]
	unsigned int funct = instr & 0x3F;
	unsigned int shamt = (instr >> 6) & 0x1F;
	unsigned int rd = (instr & 0xFFFF)>>11;
	unsigned int rt = (instr & 0x1FFFFF)>>16;
	unsigned int rs = (instr & 0x3FFFFFF)>>21;
	
	mips = "";
	for (int i = 0; i < 12; i++){
		if (funct == rFunct[i]){
			mips+=(rType[i]);
			break;
		}
	}

	if (funct==add_f || funct==addu_f || funct==and_f || funct==nor_f || funct==or_f || funct==slt_f || funct==sltu_f || funct==sub_f || funct==subu_f){
		mips += " $" + int2string(rd) + ", $" + int2string(rs) + ", $" + int2string(rt) + "\n";
	}
	else if (funct==sll_f || funct==srl_f){
		mips += " $" + int2string(rd) + ", $" + int2string(rt) + ", " + int2string(shamt) + "\n";
	}
	else if (funct==jr_f){
		mips += " $" + int2string(rs) + "\n"; 
	}
	return;
}

void encoder::encodeI(){ //I_op $rt, $rs, immed //ex// lui $s1, 20 //ex2// sc $s1,20($20)
	
	unsigned int rt = (instr>>16) & 0x1F;
	unsigned int rs = (instr>>21) & 0x1F;
	unsigned int imm = instr & 0xFFFF;

	if (opcode==addi || opcode==addiu || opcode==andi || opcode==ori || opcode==slti || opcode==sltiu) {
		mips += " $" + int2string(rt) + ", $" + int2string(rs) + ", 0x" + int2hex(imm) + "\n";
	} else if (opcode==beq || opcode==bne){
		mips += " $" + int2string(rs) + ", $" + int2string(rt) + ", 0x" + int2hex(imm) + "\n";
	} else if (opcode==lw || opcode==lbu || opcode==lhu || opcode==sb || opcode==sh || opcode==sw){
		mips += " $" + int2string(rt) + ", ";
		if ((instr & 8000) > 0){ // add negative sign //need to signextend immediate
			imm = (~imm+1) & 0xFFFF;
			mips+= "-";
		}
		mips += int2string(imm) + "($" + int2string(rs) + ")" + "\n";
	} 
	else if (opcode==lui){
		mips += " $" + int2string(rt) + ", 0x" + int2hex(imm) + "\n";
	}
	else cout << "ERRORRRRRRRRRRRRRRRRRRRRR" << endl;
}

void encoder::encodeJ(){
	unsigned int imm = instr & 0x3FFFFFF;
	mips += " 0x" + int2hex(imm) + "\n";
}


string encoder::int2string(int passed){
	vector<int> rev;
	string ret="";
	do {
//		cout << endl<< "passed : " << passed;
		rev.push_back(passed%10);
		passed = passed/10;
	} while (passed > 0);
	while (!rev.empty()){
    	ret += char(rev.back()+48);
    	rev.pop_back();
  	}
	return ret;
}

string encoder::int2hex(unsigned int passed){
	string hex[]={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"};
	vector<int> rev;
	string ret="";
	for (int i = 0; i < 4; i++){
		rev.push_back(passed%16);
		passed = passed/16;
	} 
	for (int i = 0; i < 4; i++){
    	ret += hex[rev.back()];
    	rev.pop_back();
  	}
	return ret;
}

void encoder::hex2dec(){
	unsigned int regVal = 0;
	for (unsigned int i = 0; i < 8; i++) {
	  	for (int k = 0; k < 16; k++) {
	  		if (line.at(i)==hex[k]) {
	  			regVal += k*pow(16,7-i);
		  		break;
		  	}
	  	}
	}
	instr = regVal;
}


#endif