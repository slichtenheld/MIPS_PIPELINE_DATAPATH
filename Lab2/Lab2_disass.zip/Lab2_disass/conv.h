#ifndef CONV_H
#define CONV_H

//binary <-> hex <-> decimal
#include <string>
#include <vector>
using namespace std;

string int2bit(int);
string int2hex(int);


string int2bit(int address){
	vector<int> rev;
	int count=0;
	string ret="0b";
	while (address > 0){
		rev.push_back(address%2);
		address = address/2;
		count++;
	}
	for (int i=count-1;i>=0;i--){
		if (rev.at(i)==1) ret.append("1");
		else ret.append("0");
	}
	return ret;
}



string int2hex(int address){
	string hex[]={"0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"};
	vector<int> rev;
	int count=0;
	string ret="0x";
	while (address > 0){
		rev.push_back(address%16);
		address = address/16;
		count++;
	}
	for (int i=count-1;i>=0;i--){
		ret.append(hex[rev.at(i)]);
	}
	return ret;
}

#endif