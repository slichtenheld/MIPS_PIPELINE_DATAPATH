#ifndef FILEIO_H
#define FILEIO_H

#include <cstring>
#include <string>
#include <vector>
#include <fstream>
using namespace std;
#include "conv.h"


vector<string> readfile (char*);
void newfile(char*);
void appendfile(string, string);



vector<string> readfile (char* inputTxt){
    string line;
    vector<string> str; //returning string post-edits
    ifstream inFile (inputTxt); 
    //check to see if able to open file
    if (inFile.is_open()) {
        //put each line in different line of vector of string
        bool check = false;
        while (getline(inFile,line)) {
            if (check) {
                if (line.find("[")==string::npos){
                    line = line.erase(0,line.find(":")+1);
                    while (line.at(0)==' ') line = line.erase(0,1);
                    line=line.substr(0,8);
                    str.push_back(line);
                }
            }
            else {
                if (line.find("CONTENT BEGIN")!= string::npos) check = true;
            }
              
        }
        inFile.close();
    }
    else cout << "File not found." << endl;
    str.pop_back();
    return str;
}
    
void newfile(char* filename){
    ofstream newfile (filename);
    if (newfile.is_open()) {
            newfile.close();
        }
    else std::cout << "Unable to open file WRITE" << std::endl;
}


//void appendfile()
void appendfile(string entry, string name) { 
    ofstream file (name.c_str(), ofstream::app);
    if (file.is_open()) {
        file << entry;
        file.close();
    }
    else cout << "Unable to open file APPEND" << endl;      
} 

#endif